# Norway ERP Software Market Dataset

This dataset is created from publicly available summary information from the Norway ERP Software Market report by NextMSC.

## Files Included
- **market_overview.csv** – Key market metrics for 2024, 2025, and 2030.
- **segmentation.csv** – Segmentation by component, deployment model, enterprise size, and industry vertical.
- **metadata.json** – Source metadata, reference URL, and extraction notes.

## Source
Norway ERP Software Market – NextMSC (public summary only)

## Usage
Intended for:
- Market trend and growth analysis
- Academic & business research
- Modeling and data visualization

## Disclaimer
Contains only publicly accessible summary-level information. No proprietary or paid data included.
